<?php
/**
 * ShopEx licence
 *
 * @copyright  Copyright (c) 2005-2010 ShopEx Technologies Inc. (http://www.shopex.cn)
 * @license  http://ecos.shopex.cn/ ShopEx License
 */
$setting['author']='jxwinter';
$setting['name']='可循环文字链';
$setting['version']='1.0.1';
$setting['stime']='2012-4-10';
$setting['catalog']='其他挂件';
$setting['usual'] = '0';
$setting['description']='本挂件可添加多个文字链接';
$setting['userinfo']='点击《添加链接》按钮即可。';
$setting['template'] = array(
                            'default.html'=>'信息条'
                        );
?>
